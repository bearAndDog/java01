package com.itheima.controller.groups;
//用于设定分组校验中的组名，当前接口仅提供字节码，用于识别
public interface GroupA {
}
