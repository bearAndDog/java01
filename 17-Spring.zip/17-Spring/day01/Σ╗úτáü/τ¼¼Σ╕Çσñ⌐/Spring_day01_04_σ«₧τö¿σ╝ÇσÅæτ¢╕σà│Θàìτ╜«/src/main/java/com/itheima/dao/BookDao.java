package com.itheima.dao;

public interface BookDao {
    public void save();
}
