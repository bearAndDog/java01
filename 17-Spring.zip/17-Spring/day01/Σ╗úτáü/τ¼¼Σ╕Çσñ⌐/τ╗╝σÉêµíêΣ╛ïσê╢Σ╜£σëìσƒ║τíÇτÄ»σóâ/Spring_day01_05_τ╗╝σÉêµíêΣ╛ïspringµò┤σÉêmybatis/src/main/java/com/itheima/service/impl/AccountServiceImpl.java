package com.itheima.service.impl;

import com.itheima.dao.AccountDao;
import com.itheima.domain.Account;
import com.itheima.service.AccountService;

import java.util.List;

/**
 * @author 黑马程序员
 * @Company http://www.itheima.com
 */
public class AccountServiceImpl implements AccountService {

    public void save(Account account) {

    }

    public void update(Account account){

    }

    public void delete(Integer id) {

    }

    public Account findById(Integer id) {
        return null;
    }

    public List<Account> findAll() {
        return null;
    }
}
